package Comparators;

public enum SortBy {
	POSITION, NAME, WINS, DRAWS, LOSES, SCOREGOALS, DEFEATGOALS, GOALDIF, POINTS;
}
