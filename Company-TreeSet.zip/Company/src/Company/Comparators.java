package Company;

public enum Comparators {
	AGE, NAME, SALARY
}
