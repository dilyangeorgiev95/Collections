package Vehicle;

public enum VehicleType {
	CAR,BUS,TRUCK
}
