package departments;

public class Orthopedy extends Deparment{
	
	public Orthopedy() {
		super();
	}
	
	
}
