package departments;

public class Cardiology extends Deparment{
	
	public Cardiology() {
		super();
	}
	
	
}
