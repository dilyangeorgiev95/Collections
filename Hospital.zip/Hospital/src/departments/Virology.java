package departments;

public class Virology extends Deparment{

	public Virology() {
		super();
	}	
	
}
